self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "3ae7443107b26c05b10d9ab845370853",
    "url": "/index.html"
  },
  {
    "revision": "5abfbd6a4be8afa8c31e",
    "url": "/static/css/2.72afb26d.chunk.css"
  },
  {
    "revision": "5abfbd6a4be8afa8c31e",
    "url": "/static/js/2.bc47aa36.chunk.js"
  },
  {
    "revision": "efc8fc6292722a45a077",
    "url": "/static/js/main.551b9395.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "3468c9c1eca4e1901db98beff096f0d2",
    "url": "/static/media/arrow-back.3468c9c1.svg"
  },
  {
    "revision": "b2096af92ecdd40feabc6b0d09523844",
    "url": "/static/media/arrow-forward.b2096af9.svg"
  },
  {
    "revision": "777b93c6d5a7b86081144f8d0d3ca1d8",
    "url": "/static/media/close.777b93c6.svg"
  },
  {
    "revision": "fe0a550e60d45358e4237988d15e54c6",
    "url": "/static/media/critical.fe0a550e.svg"
  },
  {
    "revision": "e18488d4cdff4dc2ce3926887ceec24c",
    "url": "/static/media/endangered.e18488d4.svg"
  },
  {
    "revision": "9d3419af2293e24de407c641da5cd5c3",
    "url": "/static/media/near-threatened.9d3419af.svg"
  },
  {
    "revision": "c6daa6761bc1473b02c5c8cadacad5dc",
    "url": "/static/media/trending-down.c6daa676.svg"
  },
  {
    "revision": "57724b95333639ef1754b88c9c05f2ba",
    "url": "/static/media/trending-up.57724b95.svg"
  },
  {
    "revision": "6fae172661bd7b4a09bdc64308495c1b",
    "url": "/static/media/vulnerable.6fae1726.svg"
  }
]);